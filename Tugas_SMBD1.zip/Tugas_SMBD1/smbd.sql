-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Waktu pembuatan: 02 Okt 2023 pada 07.16
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smbd`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `Login_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemantauan`
--

CREATE TABLE `pemantauan` (
  `id_pemantauan` int(10) NOT NULL,
  `id_pengukuran` int(4) NOT NULL,
  `id_suhu` int(4) NOT NULL,
  `id_gas` int(4) NOT NULL,
  `id_buah` int(4) NOT NULL,
  `nilai_gas` int(10) NOT NULL,
  `nilai_suhu` int(10) NOT NULL,
  `berat_buah` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pemantauan`
--

INSERT INTO `pemantauan` (`id_pemantauan`, `id_pengukuran`, `id_suhu`, `id_gas`, `id_buah`, `nilai_gas`, `nilai_suhu`, `berat_buah`) VALUES
(0, 2346, 107, 208, 309, 25, 30, 4),
(1, 123, 101, 201, 301, 10, 20, 5),
(2, 345, 104, 204, 305, 25, 10, 10);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Login_id`);

--
-- Indeks untuk tabel `pemantauan`
--
ALTER TABLE `pemantauan`
  ADD PRIMARY KEY (`id_pemantauan`),
  ADD UNIQUE KEY `id_suhu` (`id_suhu`),
  ADD UNIQUE KEY `id_gas` (`id_gas`),
  ADD UNIQUE KEY `id_buah` (`id_buah`),
  ADD UNIQUE KEY `id_pengukuran` (`id_pengukuran`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `Login_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
