<?php
// koneksi Database
include("inc_koneksi.php");


$server = "127.0.0.1:3307";
$user = "root";
$pass = "";
$database = "rumah_sakit";

// buat koneksi
$koneksi = mysqli_connect($server, $user, $pass, $database) or die(mysqli_error($koneksi));

// jika tombol simpan di klik
if (isset($_POST['bsimpan'])) {

  //  pengujian apakah data akan disimpan atau diedit
  if (isset($_GET['hal']) == "edit") {

    // data akan diedit
    $edit = mysqli_query($koneksi, "UPDATE  pasien SET
                                      NIK= '$_POST[tNIK]',
                                      Nama= '$_POST[tnama]',
                                      Umur= '$_POST[tumur]',
                                      Jenis_Kelamin= '$_POST[tjenis_kelamin]',
                                      Alamat= '$_POST[talamat]',
                                      Penyakit= '$_POST[tpenyakit]',
                                      tgl_masuk= '$_POST[tmasuk]',
                                      tgl_keluar= '$_POST[tkeluar]',
                                      pembayaran= '$_POST[tjenis_pembayaran]'
                                    WHERE id_pasien = '$_GET[id]'
                                   ");
    //  uji jika edit data berhasil
    if ($edit) {
      echo "<script>
          alert('edit data berhasil');
          document.location='index.php';
    
        </script>";
    } else {
      echo "<script>
          alert('edit data gagal');
          document.location='index.php';
    
        </script>";
    }
  } else {
    // jika bukan edit maka data akan di simpan baru
    // Data akan di simpan adalah data baru
    $simpan = mysqli_query($koneksi, " INSERT INTO pasien (NIK,Nama,Umur,Jenis_Kelamin,Alamat,Penyakit,tgl_masuk,tgl_keluar,pembayaran)
  VALUE('$_POST[tNIK]',
        '$_POST[tnama]',
        '$_POST[tumur]',
        '$_POST[tjenis_kelamin]',
        '$_POST[talamat]',
        '$_POST[tpenyakit]',
        '$_POST[tmasuk]',
        '$_POST[tkeluar]',
        '$_POST[tjenis_pembayaran]' )
  
                       ");
    //  uji jika simpan data berhasil
    if ($simpan) {
      echo "<script>
          alert('Simpan data berhasil');
          document.location='index.php';
    
        </script>";
    } else {
      echo "<script>
          alert('Simpan data gagal');
          document.location='index.php';
    
        </script>";
    }

  }


}


// deklarasi variabel untuk menampung data yang akan di edit
$vNIK = "";
$vNama = "";
$vUmur = "";
$vJenis_Kelamin = "";
$vAlamat = "";
$vPenyakit = "";
$vtgl_masuk = "";
$vtgl_keluar = "";
$vpembayaran = "";



// pengujian jika tombol edit atau diihapus di klik

if (isset($_GET['hal'])) {

  // pengujian jika edit data
  if ($_GET['hal'] == "edit") {
    // tampilkan data yang akan diedit
    $tampil = mysqli_query($koneksi, "SELECT * FROM pasien WHERE id_pasien = '$_GET[id]'");
    $data = mysqli_fetch_array($tampil);
    if ($data) {
      // jika data ditemukan maka data ditampung dalam variabel
      $vNIK = $data['NIK'];
      $vNama = $data['Nama'];
      $vUmur = $data['Umur'];
      $vAlamat = $data['Alamat'];
      $vJenis_Kelamin = $data['Jenis_Kelamin'];
      $vPenyakit = $data['Penyakit'];
      $vtgl_masuk = $data['tgl_masuk'];
      $vtgl_keluar = $data['tgl_keluar'];
      $vpembayaran = $data['pembayaran'];
    }

  } else if ($_GET['hal'] == "hapus") {
    // persiapan hapus data
    $hapus = mysqli_query($koneksi, "DELETE FROM Pasien WHERE id_pasien ='$_GET[id]'");

    //  uji jika hapus data berhasil
    if ($hapus) {
      echo "<script>
          alert('hapus data berhasil');
          document.location='index.php';
    
        </script>";
    } else {
      echo "<script>
          alert('hapus data gagal');
          document.location='index.php';
    
        </script>";
    }

  }
}





?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tugas SMBD</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
  <!-- awal container -->
  <div class="container">
    <h3 class="text-center">Data Pasien Rumah Sakit Manggis Tahun 2023<h3>
        <!-- awal row -->
        <div class="row" style="font-size:15px;">
          <!-- awal col-md-7 mx-auto -->
          <div class="col-md-7 mx-auto">
            <!-- akhir col-md-7 mx-auto -->
            <!-- awal card -->
            <div class="card ">
              <div class="card-header bg-warning text-light">
                Form Input Data Pasien
              </div>
              <div class="card-body">
                <!--  Awal form -->
                <form method="POST">
                  <div class="mb-3">
                    <label class="form-label">NIK Pasien</label>
                    <input type="text" name="tNIK" value="<?= $vNIK ?>" class="form-control"
                      placeholder="Masukkan NIK pasien">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Nama pasien</label>
                    <input type="text" name="tnama" value="<?= $vNama ?>" class="form-control"
                      placeholder="Masukkan nama pasien">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Umur pasien</label>
                    <input type="text" name="tumur" value="<?= $vUmur ?>" class="form-control"
                      placeholder="Masukkan umur pasien">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Jenis Kelamin</label>
                    <select class="form-select" name="tjenis_kelamin">
                      <option value="<?= $vJenis_Kelamin ?>">
                        <?= $vJenis_Kelamin ?>
                      </option>
                      </option>
                      <option value="Laki-laki">Laki-laki</option>
                      <option value="Perempuan">Perempuan</option>
                    </select>
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Alamat Pasien</label>
                    <input type="text" name="talamat" value="<?= $vAlamat ?>" class="form-control"
                      placeholder="Masukkan Alamat pasien">
                  </div>
                  <div class="mb-3">
                    <label class="form-label">Penyakit pasien</label>
                    <input type="text" name="tpenyakit" value="<?= $vPenyakit ?>" class="form-control"
                      placeholder="Masukkan Penyakit pasien">
                  </div>
                  <div class="row">
                    <div class="col">
                      <div class="mb-3">
                        <label class="form-label">Tanggal masuk pasien</label>
                        <input type="date" name="tmasuk" value="<?= $vtgl_masuk ?>" class="form-control"
                          placeholder="Masukkan tanggal masuk pasien">
                      </div>
                    </div>
                    <div class="col">
                      <div class="mb-3">
                        <label class="form-label">Tanggal keluar pasien</label>
                        <input type="date" name="tkeluar" value="<?= $vtgl_keluar ?>" class="form-control"
                          placeholder="Masukkant tanggal keluarpasien">
                      </div>
                    </div>
                    <div class="col">
                      <div class="mb-3">
                        <label class="form-label">Jenis Pembayaran</label>
                        <select class="form-select" name="tjenis_pembayaran">
                          <option value="<?= $vpembayaran ?>">
                            <?= $vpembayaran ?>
                          </option>
                          <option value="Laki-laki">Umum</option>
                          <option value="Perempuan">BPJS</option>
                        </select>
                      </div>
                    </div>
                    <div class="text-center">
                      <hr>
                      <button class=" btn btn-primary" name="bsimpan" type="submit">Simpan Data</button>
                      <button class=" btn btn-danger" name="bhapus" type="reset">Hapus Data</button>
                    </div>
                  </div>

                </form>
                <!-- Akhir form -->



              </div>
              <div class="card-footer bg-warning">
              </div>
            </div>
            <!-- akhir card -->
          </div>
          <!-- akhir col-md-7 mx-auto -->
        </div>
        <!-- akhir row -->

        <div class="card mt-5  mx-auto">
          <div class="card-header bg-warning text-light">
            Data Pasien
          </div>
          <div class="card-body">
            <div class="col-md-6 mx-auto">
              <form method="POST">
                <div class="input-group mb-3">
                  <input type="text" name="tcari" value="<?= $_POST['bcari'] ?>" class="form-control"
                    placeholder="Masukkan kata kunci">
                  <button class="btn btn-primary" name="bcari" type="submit">Cari</button>
                  <button class="btn btn-danger" name="breset" type="reset">Reset</button>
                </div>
              </form>
            </div>
            <table class=" table table-striped table-hover table-bordered" style="font-size:13px;">
              <tr>
                <th>No.</th>
                <th>NIK</th>
                <th>Nama</th>
                <th>Umur</th>
                <th>Jenis Kelamin</th>
                <th>Alamat</th>
                <th>Penyakit</th>
                <th>tgl masuk</th>
                <th>tgl keluar</th>
                <th>Pembayaran</th>
                <th>Aksi</th>
              </tr>

              <?php
              // persiapan menampilkan data
              $no = 1;

              // untuk mencari data
              // jika tombol  cari di klik
              if (isset($_POST['tcari'])) {
                //menampilkan data yang dicari
                $keyword = $_POST['bcari'];
                $q = "SELECT * FROM pasien WHERE NIK like '%$keyword%' or Nama like '%$keyword%' order by id_pasien desc";
              } else {
                $q = "SELECT * FROM Pasien order by id_pasien desc";
              }



              $tampil = mysqli_query($koneksi, $q);
              while ($data = mysqli_fetch_array($tampil)):

                ?>
                <tr>
                  <td>
                    <?= $no++ ?>
                  </td>
                  <td>
                    <?= $data['NIK'] ?>
                  </td>
                  <td>
                    <?= $data['Nama'] ?>
                  </td>
                  <td>
                    <?= $data['Umur'] ?>
                  </td>
                  <td>
                    <?= $data['Jenis_Kelamin'] ?>
                  </td>
                  <td>
                    <?= $data['Alamat'] ?>
                  </td>
                  <td>
                    <?= $data['Penyakit'] ?>
                  </td>
                  <td>
                    <?= $data['tgl_masuk'] ?>
                  </td>
                  <td>
                    <?= $data['tgl_keluar'] ?>
                  </td>
                  <td>
                    <?= $data['pembayaran'] ?>
                  </td>
                  <td>
                    <a href="index.php?hal=edit&id=<?= $data['id_pasien'] ?>" class="btn btn-primary">Edit</a>


                    <a href="index.php?hal=hapust&id=<?= $data['id_pasien'] ?>" class=" btn btn-danger"
                      onclick="return confirm('Apakah anda yakin akan menghapus data ini')">Hapus</a>
                  </td>
                </tr>
              <?php endwhile; ?>
            </table>
          </div>
          <div class="card-footer bg-warning">
          </div>
        </div>


  </div>

  <!-- akhir container -->






  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
    crossorigin="anonymous"></script>
</body>

</html>