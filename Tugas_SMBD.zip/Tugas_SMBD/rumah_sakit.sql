-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Waktu pembuatan: 02 Okt 2023 pada 07.15
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rumah_sakit`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `login_id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`login_id`, `username`, `password`) VALUES
(1, 'admin', '25f9e794323b453885f5181f1b624d0b'),
(2, 'intenrukmana', 'ad790931d6674272ef8c538df2097ead');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien`
--

CREATE TABLE `pasien` (
  `id_pasien` int(11) NOT NULL,
  `NIK` varchar(15) NOT NULL,
  `Nama` varchar(25) NOT NULL,
  `Umur` varchar(25) NOT NULL,
  `Jenis_Kelamin` varchar(25) NOT NULL,
  `Alamat` varchar(50) NOT NULL,
  `Penyakit` varchar(25) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `tgl_keluar` date NOT NULL,
  `pembayaran` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pasien`
--

INSERT INTO `pasien` (`id_pasien`, `NIK`, `Nama`, `Umur`, `Jenis_Kelamin`, `Alamat`, `Penyakit`, `tgl_masuk`, `tgl_keluar`, `pembayaran`) VALUES
(1, '6100034572', 'Muhammad Fajar', '21 tahun', 'Laki-laki', 'Singkawang', 'Asma', '2023-09-06', '2023-09-13', 'umum'),
(2, '6100034573', 'Aminah', '50', 'Perempuan', 'Sejangkung', 'Hipertensi', '2023-09-10', '2023-09-13', 'BPJS'),
(5, '6100034574', 'Maulana', '25', 'Laki-laki', 'Parit Raja', 'Tipes', '2023-06-21', '2023-06-27', 'umum'),
(6, '	6100034575', 'Maratul hasanah', '25', 'Perempuan', 'Sendoyan', 'Diabetes', '2023-01-17', '2023-01-18', 'Umum'),
(7, '	6100034576', 'Inten Rukmana', '21', 'Perempuan', 'Gambir', 'Sakit Kepala', '2023-03-07', '2023-03-07', 'Laki-laki');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`login_id`) USING BTREE;

--
-- Indeks untuk tabel `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`id_pasien`),
  ADD UNIQUE KEY `NIK` (`NIK`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `pasien`
--
ALTER TABLE `pasien`
  MODIFY `id_pasien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
